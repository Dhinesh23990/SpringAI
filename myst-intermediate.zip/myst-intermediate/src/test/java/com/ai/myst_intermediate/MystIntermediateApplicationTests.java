package com.ai.myst_intermediate;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MystIntermediateApplicationTests {

	@Test
	void contextLoads() {
	}

}
