package com.ai.myst_intermediate.controller;

import java.io.File;
import java.io.IOException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.ai.myst_intermediate.dto.JobDescriptionRequest;
import com.ai.myst_intermediate.dto.JobDescriptionResponse;
import com.ai.myst_intermediate.service.JobParsingService;

import jakarta.validation.Valid;

@RestController
public class AIController {
	@Autowired
	private JobParsingService jobParsingService;

	@PostMapping("/ai")
	public JobDescriptionResponse completion(@Valid @RequestBody JobDescriptionRequest request) {
		return jobParsingService.parseJobDescription(request.jd());
	}

	@PostMapping("/job-description")
	public ResponseEntity<JobDescriptionResponse> parseJobDescriptionFromPdf(@RequestBody MultipartFile file)
			throws IOException {
		File tempFile = File.createTempFile("job-description", ".pdf");
		file.transferTo(tempFile);
		JobDescriptionResponse parsedJob = jobParsingService.parseJobDescriptionFromPDF(tempFile);
		return ResponseEntity.ok(parsedJob);
	}
}
