package com.ai.myst_intermediate.dto;

import jakarta.validation.constraints.NotBlank;

public record JobDescriptionRequest(@NotBlank(message = "Job description must not be empty") String jd) {

}
