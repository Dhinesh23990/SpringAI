package com.ai.myst_intermediate.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.Data;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class JobDescriptionResponse {

	private String currency;
	private String jdType;
	private String jdCompany;
	private long deadline;
	private String jdsQualification;
	private String salaryLow;
	private String salaryHigh;
	private String openings;
	private String requirements;
	private String benefits;
	private String responsibilities;
	private String experience;
	private String experienceUnit;
	private String jobLocation;
	private String title;
	private String description;

}
