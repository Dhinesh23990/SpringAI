package com.ai.myst_intermediate.service;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.util.Base64;

import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.text.PDFTextStripper;
import org.springframework.ai.chat.client.ChatClient;
import org.springframework.ai.chat.messages.SystemMessage;
import org.springframework.ai.chat.messages.UserMessage;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ai.myst_intermediate.dto.JobDescriptionResponse;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

@Service
public class JobParsingService {

	@Autowired
	private ChatClient chatClient;

	public JobDescriptionResponse parseJobDescription(String jobDescription) {
		JobDescriptionResponse response = new JobDescriptionResponse();
		try {
			String aiResponse = getChatResponse(jobDescription);
			ObjectMapper objectMapper = new ObjectMapper();
			response = objectMapper.readValue(aiResponse, JobDescriptionResponse.class);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return response;
	}

	private String getChatResponse(String jobDescription) {
		SystemMessage systemMessage = new SystemMessage(
				"You are a helpful assistant that parses job descriptions into structured JSON format.");
		UserMessage userMessage = new UserMessage(
				"Please parse the following job description into this exact JSON format: "
						+ "{'currency': '', 'jdType': '', 'jdCompany': '', 'deadline': '', 'jdsQualification': '', "
						+ "'salaryLow': '', 'salaryHigh': '', 'openings': '', 'requirements': '', 'benefits': '', "
						+ "'responsibilities': '', 'experience': '', 'experienceUnit': '', 'jobLocation': '', 'title': '', 'description': ''}. "
						+ "Ensure the JSON response is in plain format without any markdown or code block formatting such as backticks. "
						+ "For the 'deadline' field should contain the 'Drive Date' in the format DD-MMM-YY mentioned in the job description. Ensure convert into a Unix timestamp of the local timezone. "
						+ "If no drive date is provided, leave the 'deadline' field empty. "
						+ "The 'jdsQualification' should contain the 'Job skill'. "
						+ "If no skills are explicitly listed, leave 'jdsQualification' empty. "
						+ "The 'requirements' should contain the skills listed under 'Must-Have' or 'desired'. "
						+ "If requirements fields are not explicitly mentioned, leave the 'requirements' field empty. "
						+ "The 'openings' should contains the number of 'applicants'. "
						+ "If no applicants is provided, leave 'openings' empty. "
						+ "The 'responsibilities' field should contain the specific job duties or responsibilities mentioned in the job description. "
						+ "If responsibilities are not explicitly mentioned, leave the 'responsibilities' field empty. "
						+ "Ensure 'experience' contains only the numeric range (e.g., '5 to 7') and 'experienceUnit' contains the time unit (e.g., 'months'). "
						+ "Job description: \"" + jobDescription + "\"");

		return chatClient.prompt().user(systemMessage.getContent() + "\n\n" + userMessage.getContent()).call()
				.content();
	}

	public JobDescriptionResponse parseJobDescriptionFromPDF(File pdfFile) {
		JobDescriptionResponse response = new JobDescriptionResponse();
		try {
			String jobDescription = extractTextFromPdf(pdfFile);
			if (jobDescription == null || jobDescription.isEmpty()) {
				throw new RuntimeException("Failed to extract text from PDF file.");
			}
			String aiResponse = getChatResponse(jobDescription);
			ObjectMapper objectMapper = new ObjectMapper();
			response = objectMapper.readValue(aiResponse, JobDescriptionResponse.class);
		} catch (JsonProcessingException e) {
			e.printStackTrace();
		}
		return response;
	}

	private String extractTextFromPdf(File pdfFile) {
		try (PDDocument document = PDDocument.load(pdfFile)) {
			PDFTextStripper pdfStripper = new PDFTextStripper();
			return pdfStripper.getText(document);
		} catch (IOException e) {
			e.printStackTrace();
			return null;
		}
	}

	public JobDescriptionResponse parseJobDescriptionUsingBase64(File pdfFile) {
		JobDescriptionResponse response = new JobDescriptionResponse();
		try {
			String base64Pdf = convertPdfToBase64(pdfFile);
			if (base64Pdf == null || base64Pdf.isEmpty()) {
				throw new RuntimeException("Failed to convert PDF file to Base64.");
			}
			SystemMessage systemMessage = new SystemMessage(
					"You are a helpful assistant that parses job descriptions from a PDF encoded in Base64 into structured JSON format.");
			UserMessage userMessage = new UserMessage(
					"Please parse the following PDF (encoded in Base64) into this exact JSON format: "
							+ "{'currency': '', 'jdType': '', 'jdCompany': '', 'deadline': '', 'jdsQualification': '', "
							+ "'salaryLow': '', 'salaryHigh': '', 'openings': '', 'requirements': '', 'benefits': '', "
							+ "'responsibilities': '', 'experience': '', 'experienceUnit': '', 'jobLocation': '', 'title': '', 'description': ''}. "
							+ "Ensure the JSON response is in plain format without any markdown or code block formatting such as backticks. "
							+ "For the 'deadline' field should contain the 'Drive Date' in the format DD-MMM-YY mentioned in the job description. Ensure convert into a Unix timestamp of the local timezone. "
							+ "If no drive date is provided, leave the 'deadline' field empty. "
							+ "The 'jdsQualification' should contain the 'Job skill'. "
							+ "If no skills are explicitly listed, leave 'jdsQualification' empty. "
							+ "The 'requirements' should contain the skills listed under 'Must-Have' or 'desired'. "
							+ "If requirements fields are not explicitly mentioned, leave the 'requirements' field empty. "
							+ "The 'openings' should contains the number of 'applicants'. "
							+ "If no applicants is provided, leave 'openings' empty. "
							+ "The 'responsibilities' field should contain the specific job duties or responsibilities mentioned in the job description. "
							+ "If responsibilities are not explicitly mentioned, leave the 'responsibilities' field empty. "
							+ "Ensure 'experience' contains only the numeric range (e.g., '5 to 7') and 'experienceUnit' contains the time unit (e.g., 'months'). "
							+ "Here is the Base64-encoded PDF content: \"" + base64Pdf + "\"");

			String aiResponse = chatClient.prompt().user(systemMessage.getContent() + "\n\n" + userMessage.getContent())
					.call().content();
			ObjectMapper objectMapper = new ObjectMapper();
			response = objectMapper.readValue(aiResponse, JobDescriptionResponse.class);
		} catch (JsonProcessingException e) {
			e.printStackTrace();
		}
		return response;
	}

	private String convertPdfToBase64(File pdfFile) {
		try {
			byte[] fileContent = Files.readAllBytes(pdfFile.toPath());
			return Base64.getEncoder().encodeToString(fileContent);
		} catch (IOException e) {
			e.printStackTrace();
			return null;
		}
	}
}