package com.ai.myst_intermediate;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MystIntermediateApplication {

	public static void main(String[] args) {
		SpringApplication.run(MystIntermediateApplication.class, args);
	}

}
